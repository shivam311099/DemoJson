package com.imagineage.model;

import java.util.List;

import lombok.Data;

@Data
public class Project {
	private Integer pid;
	private String pname;
	private List<Module1> mods;
}
