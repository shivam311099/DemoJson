package com.imagineage.model;

import java.util.HashMap;
import java.util.List;

import lombok.Data;

@Data
public class Model {
	private List<Integer> eid;
	private HashMap<Integer, String> map;
	private String ename;
	private double esal;
}
