package com.imagineage.model;

import lombok.Data;

@Data
public class Module1 {
	private Integer mid;
	private String mname;
	private Info inf;//has-a
	
}
