package com.imagineage.model;

import lombok.Data;

@Data
public class Info {
	private Integer did;
	private String code;
	private String format;
	
}
