package com.imagineage.test;

import java.util.Arrays;import java.util.HashMap;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.imagineage.model.Model;

public class Test {
	public static void main(String[] args) {

		
//		  Model m=new Model(); 
//		  HashMap<Integer, String> al=new HashMap<Integer, String>();
//		  al.put(1, "A");
//		  al.put(2, "As");
//		  al.put(3, "sA");
//		  al.put(4, "Aa");
//		  m.setEid(Arrays.asList(101,120,111));
//		  m.setEname("AB");
//		  m.setMap(al);
//		  m.setEsal(3.9);
//		  ObjectMapper om=new ObjectMapper(); String json=null; try { json =
//		  om.writeValueAsString(m); } catch (JsonProcessingException e) {
//		  e.printStackTrace(); } System.out.println(json);
		
try {
	String json="{\"eid\":[101,120,111],\"map\":{\"1\":\"A\",\"2\":\"As\",\"3\":\"sA\",\"4\":\"Aa\"},\"ename\":\"AB\",\"esal\":3.9}";
	ObjectMapper om=new ObjectMapper();
	Model m=om.readValue(json,Model.class);
	System.out.println(m);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
