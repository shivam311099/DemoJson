package com.imagineage.test;

import java.util.Arrays;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.imagineage.model.Info;
import com.imagineage.model.Module1;
import com.imagineage.model.Project;

public class Test2 {
	public static void main(String[] args) {
		try {
			Info in=new Info();
			in.setDid(1011);
			in.setCode("ABS");
			in.setFormat("Diso");
			Module1 m=new Module1();
			m.setInf(in);
			m.setMid(190);
			m.setMname("Mod");
			Module1 m1=new Module1();
			m1.setInf(in);
			m1.setMid(1901);
			m1.setMname("Mod1");
			Project p=new Project();
			p.setMods(Arrays.asList(m,m1));
			p.setPid(999);
			p.setPname("IMG");
			ObjectMapper om=new ObjectMapper();
			String json=om.writeValueAsString(p);
			System.out.println(json);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
